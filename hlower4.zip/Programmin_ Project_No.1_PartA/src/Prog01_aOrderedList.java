/*
 * CSC 1351
 * CSC 1351 Programming Project No 1.
 * Section 002
 * @author Hannah Lowery
 * @since 03/17/2024
 * */
public class Prog01_aOrderedList {
    /*
     * The main method puts all the methods together to run a fully functioning program
     *
     * @param fileResult stores the result of the userInput method so that it doesn't have to keep calling the method
     *
     * CSC 1351 Programming Project No 1.
     * Section 002
     * @Author Hannah Lowery
     * @Since 03/17/2024
     *
     * Program overview: The program starts by prompting the user to write the current file or skip that step
     * the program then prompts the user for the file input, then  it prints the unedited file to the console,
     * after it deletes the unedited file and then prints the final output.
     *
     * */
    public static void main(String[] args){
        //the file data has to be seperated by tabs not commas I provided an input files (input.txt) but you can write
        // + your own via the program or a textpad
        //the output file name is car.txt

        aOrderedList.Output.work(); //the work() method from a the inner-class "Output" is called to ask the user to create a PrinterWriter object
        String fileResult =  FileIn.userInput();
        aOrderedList.outPrint(fileResult); //gets the file result and prints the undeleted result to the console
        aOrderedList.deleting(fileResult,"car.txt"); //makes car.txt the output file and uses the fileResult as the input
        Car.outPrint();  //calls the outPrint() method in the Car class to print the final result
    }
}

