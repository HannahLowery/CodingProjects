import javax.swing.*;
import java.io.*;
import java.text.NumberFormat;
import java.util.Arrays;
import java.util.LinkedList;
/*
 * CSC 1351
 *
 * CSC 1351 Programming Project No 1.
 * Section <002>

 * @author Hannah Lowery
 * @Since 03/17/2024
 *
 * aOrderedList class puts the inner-class Output together in a clean way
 * */

public class aOrderedList {

    /*
     * deleting method takes in two parameters and calls the delete method to delete the file
     *
     * @param fileInput gets the file created
     * @param output creates an output file from the inputted file
     *
     * CSC 1351 Programming Project No.1
     * section<002>
     *
     * @author Hannah Lowery
     * @since 03/17/2024
     * */

    public static void deleting(String fileInput, String output) {
        File inputFile = new File(fileInput);
        File outputFile = new File(output);
        Output.delete(inputFile, outputFile);
    }

    /*
     * outPrint method takes in the out-printed file from the PrintWriter and properly formats it
     * @param userInput A String that gets the users file
     * @param count Counts how many times the file is passed through the while loop
     * @param currency Properly formats the price
     * @param inputReader Stores the userInput by calling the BufferedReader inner class stores in the Car main class getReader method
     * @param readCars Calls the readCar method to read the String formatted file.
     *
     * CSC 1351 Programming Project No.1
     * section<002>
     *
     * @author Hannah Lowery
     * @since 03/17/2024
     * */
    public static void outPrint(String userInput) {
        int count = 0;

        NumberFormat currency = NumberFormat.getCurrencyInstance();
        BufferedReader inputReader = Car.bufferReader.getReader(userInput);
        Output readCars = Output.readCar(inputReader);

        //formats the console output
        System.out.println("-------------------------------------------------------------------------");
        System.out.printf("%32s%n", "Your Input of Cars");
        System.out.println("-------------------------------------------------------------------------");
        System.out.printf("| %-10s | %-15s |%-15s | %-10s |%n","A/D", "Make", "Year", "Price");

        while (readCars != null) { //makes sure the file isn't null
            System.out.println("-------------------------------------------------------------------------");

            System.out.printf("| %-10s | %-15s |% -15d | %-10s |%n", readCars.c,readCars.make, readCars.year, currency.format(readCars.price));
            count++;
            readCars = Output.readCar(inputReader); //reads the next line in the file
        }
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("Number of cars: " + count);
        Output.closeReader(inputReader); //closes the BufferedReader
    }

    /*
     * Output inner-class works to properly get PrintWriter input to get the correct output by deleting line and/or indexes
     * @param c Gets the first index ([0]) of the users input
     * @param make Gets the second index ([1]) for the make of the car
     * @param year Gets the third index ([2]) for the year of the car
     * @param price Gets the fourth index ([3]) for the price of the car
     * @param isValid Used to see if the user wants to skip or continue writing a file
     *
     * * CSC 1351 Programming Project No.1
     * section<002>
     *
     * @author Hannah Lowery
     * @since 03/17/2024
     * */

    public static class Output {
        private char c;
        private String make;
        private int year;
        private double price;
        private static boolean isValid = true;

        /*
         * Output is a constructor that initializes c,make,year,price
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024
         * */

        public Output(char c, String make, int year, double price) {
            this.c = c;
            this.make = make;
            this.year = year;
            this.price = price;


        }



        /*
         * getCar method creates an Output object
         * @param outArray Stores the OuPut values at a specific index
         * @param index Increments the output array
         * @param character_1 Prompts the user for a char input
         * @param character Stores the character_1 input
         * @param nameOfVehicle Prompts the user for a String value
         * @param yearInput Prompts the user for an int value
         * @param year Stores the yearInput
         * @param priceInput Prompts the user for a double value
         * @param price Stores the priceInput
         * @return outArray
         * @throws NumberFormatException
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024*/
        private static Output[] getCar() {
            Output[] outArray = new Output[0];
            int index = 0;
            while (true) { //loops the prompts until the user chooses to quit

                try {
                    String character_1 = JOptionPane.showInputDialog(null, "Do you want to add or delete?");
                    if (character_1 == null) { // Exit the loop if the user presses cancel
                        isValid = false;
                        break;
                    }
                    char character = Character.toUpperCase(character_1.charAt(0));

                    String nameOfVehicle = JOptionPane.showInputDialog(null, "what is the " +
                            "name of your vehicle? type \"d\" to delete");
                    if (nameOfVehicle == null) { // Exit the loop if the user presses cancel
                        isValid = false;
                        break;
                    }

                    String yearInput = JOptionPane.showInputDialog(null, "what is the year of the " + nameOfVehicle +" type \"0\" to delete");
                    if (yearInput == null) {  // Exit the loop if the user presses cancel
                        isValid = false;
                        break;
                    }
                    int year =  Integer.parseInt(yearInput);

                    String priceInput = JOptionPane.showInputDialog(null, "what is the price? type \"0\" to delete");
                    if (priceInput == null) { // Exit the loop if the user presses cancel
                        isValid = false;
                        break;
                    }

                    double price = Double.parseDouble(priceInput);


                    if (index >= outArray.length) { //if the Array is out of bounds it is put into a bigger Array
                        outArray = Arrays.copyOf(outArray, 2 * outArray.length + 1);
                    }
                    outArray[index++] = new Output(character, nameOfVehicle, year, price); //stores the new Output in the array

                    if (!Continue()) { //breaks out of the loop if the user doesn't want to continue
                        isValid = false; //makes inValid false to break out of all loops
                        break;
                    }

                }
                catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.");
                }
            }

            return Arrays.copyOf(outArray, index);
        }

        /*Continue method creates a Boolean object to see if the user would like to continue with the getCar method
         * @param b returns a boolean value
         * @param result Stores the JOptionPane value
         * @return b
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024
         * */
        private static boolean Continue() {
            boolean b = false;
            int result = JOptionPane.showConfirmDialog(null, "Would you like to continue?", "Confirm",
                    JOptionPane.YES_NO_OPTION);
            if (result == JOptionPane.YES_OPTION) //tests the users choice
                return b = true;
            return b;
        }

        /*
         * isIsValid method creates a Boolean object to see if the user wants to write an output file or skip
         * @param option Used to label the JOptionPane buttons
         * @param options Used to store the users input
         * @return isValid
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024
         *  */
        private static boolean isIsValid() {
            isValid = true;
            String[] option = {"Write", "Skip"};
            int options = JOptionPane.showOptionDialog(null, "Would you like to write file?", "File",
                    0, 3, null, option, option[0]);

            //tests the users choice
            if (options == 0) {
                isValid = true;
            } else {
                isValid = false;
            }
            return isValid;
        }

        /*
         * openWriter method creates the Printwrier object to send output file
         * @param name A parameter that stores the file as a String
         * @param out Gets the "name" to be printed out to the users directory
         * @param append Allows the user to choose if they want to overwrite the existing file or append data to it
         * @param fileWriter Gets the file name as a String and sees whether to append or overwrite the file
         * @throws IOException
         * @return out
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024
         *   */
        private static PrintWriter openWriter(String name) {
            PrintWriter out = null;
            boolean append;
            //uses a try-catch block to catch the exception
            try {
                String[] option = {"Append", "Overwrite"};
                int options = JOptionPane.showOptionDialog(null, "How would you like to write file?", "File",
                        0, 3, null, option, option[0]);
                if (options == 0) {
                    append = true;
                } else {
                    append = false;
                }
                FileWriter fileWriter = new FileWriter(name, append);
                out = new PrintWriter(fileWriter);
                return out;
            } catch (IOException e) {
                System.out.println("I/O Error opening file.");
                System.exit(0); //exits the program
            }
            return out;
        }

        /*
         * writeCar method formats the file given the Output varaibles
         * @param o Gets the Output values
         * @param out Prints o to the file
         * @param line Gets the values and prints it to the file
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024
         * */
        private static void writeCar(Output o, PrintWriter out) {
            //uses tabs to space out the make,year,and price
            String line = Character.toString(o.c);
            line += "\t" + o.make;
            line += "\t" + Integer.toString(o.year);
            line += "\t" +  Double.toString(o.price);

            out.println(line);
        }

        /* work method prints everything to the console
         * @param movies Uses an Array to store the getCar() input
         * @param output PrintWriter object to create the file for data to be written to
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024*/
        public static void work() {
            isIsValid();
            while (isValid) { //loops until the user no longer wants to continue
                Output[] movies = getCar();
                PrintWriter output = openWriter("input.txt");
                for (Output o : movies) //writes to the file until movies is null
                    writeCar(o, output);

                output.close(); //closes PrintWriter object
            }
        }

        /*
         * delete method deletes the line if it starts with "d" or it explicit deletes
         * @param inputFile Used for deletion
         * @param outputFile Created after the deletion is done
         * @param reader BufferedReader object used to read the inputFile
         * @param writer PrintWriter object used to print the outputFile
         * @param line Used to store the reader object if it isn't null
         * @param parts LinkedList object used to split the line by its tabs
         * @param index1 checks if the user type "d" if so it prints a blank space
         * @param index2 checks if the user type "0" if so it prints a blank space
         * @param index3 checks if the user type "0" if so it prints a blank space
         * @throws IOException
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024
         * */
        private static void delete(File inputFile, File outputFile) {
            //uses a try-catch block to catch errors
            try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
                 PrintWriter writer = new PrintWriter(new FileWriter(outputFile))) {

                String line;
                while ((line = reader.readLine()) != null) { //uses a while loop to ensure it isn't null
                    LinkedList<String> parts = new LinkedList<>(Arrays.asList(line.split("\\t"))); //Arrays.asList allows Arrays to be like Lists

                    //uses an if statement to ensure that parts equal A to continue reading the line if it isn't "A" it deletes the line
                    if (!parts.isEmpty() && parts.get(0).trim().equalsIgnoreCase("A")) {

                        String index1 = parts.get(1).trim(); //removes all leading and trailing space
                        if (index1.equalsIgnoreCase("d") || index1.equals("0")) {
                            parts.set(1, " ");
                        }

                        String index2 = parts.get(2).trim(); //removes all leading and trailing space
                        if (index2.equals("0")) { //checks whether the file has 0
                            parts.set(2, " ");
                        }

                        String index3 = parts.get(3).trim(); //removes all leading and trailing space
                        if (index3.equals("0.0")) { //checks whether the file has 0
                            parts.set(3, "");
                        }


                        writer.println(String.join("\t", parts)); //joining the parts back together and spacing it out by tabs
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        /*
         * readCar method creates an Output object and reads the file and stores it based on tabs
         * @param in BufferedReader object that stores a file name
         * @param make String that stores index 1
         * @param c Char that stores  index 0
         * @param year Int that stores index 2
         * @param price Double that stores index3
         * @param line Stores the file in a String
         * @param data String array that creates its indexes based on tabs
         * @throws IOException
         * @return Output
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024*/
        private static Output readCar(BufferedReader in) {
            String make;
            char c;
            int year;
            double price;
            String line = "";
            String[] data;
            //try catch block to catch the errors
            try {
                line = in.readLine();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "error reading file", "error", JOptionPane.WARNING_MESSAGE);
                System.exit(0);
            }
            if (line == null) { //tests whether the line is null
                return null;
            } else {
                data = line.split("\\t"); // everytime there is a tab in the file data gets incremented
                c = data[0].charAt(0);
                make = data[1];
                year = Integer.parseInt(data[2]);
                price = Double.parseDouble(data[3]);
                return new Output(c,make, year, price);
            }

        }

        /*
         *closeReader closes the BufferedReader
         * @param close BufferedReader object to close the BufferedReader
         * @throws IOException
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024
         * */
        private static void closeReader(BufferedReader close) {
            //try-catch block is used for exception handling
            try {
                close.close();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "error closing file", "error", JOptionPane.WARNING_MESSAGE);
                System.out.print(0); //exits the program
            }
        }


    }

}



