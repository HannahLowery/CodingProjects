import javax.swing.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;

/*
 * CSC 1351
 *
 * CSC 1351 Programming Project No 1.
 * Section <002>
 *
 * @author Hannah Lowery
 * @since 03/17/2024
 * */

/*Using a record class to create the car object that initializes the private members and compares them
 * The car class contains one public inner-class: bufferReader
 * by implementing the Comparable interface
 *
 * @param make The cars make
 * @param year the cars year
 * @param price the cars price
 * */
public record Car (String make, String year, String price )implements Comparable<Car> {

    /*compareTo method to compare the car attribute
    @return the compared values

     CSC 1351 Programming Project No.1
     Section <002>
     @author Hannah Lowery
     @since 03/17/2024
     */
    public int compareTo(Car o){
        if (!this.make.equals(o.make) ){
            return this.make.compareTo(o.make);
        }
        else if(this.price.equals(o.price) && !this.year.equals(o.year)){
            return year.compareTo( o.year);
        }
        else{
            return price.compareTo(o.price);
        }

    }

    @Override
    /*toString method overrides the toString method and creates a String object
     * @returns The new toString
     * @deprecated The method is not used
     *
     * CSC 1351 Programming Project No.1
     * section <002>
     * @author Hannah Lowery
     * @since 03/17/2024
     * */
    public String toString(){
        //creates a string to format how the toString should look when called
        return "Make: " + make + " Year: " + year + " Price: " + price;
    }

    /*
     * outPrint method takes the output file created by the deleting method in aOrderedlist class
     * and sorts it using an ArrayList and collections.sort
     *
     * @param count Keeps count of how many times the for loop is called
     * @param currency Creates a currency Instance for the price
     * @param inputReader Stores the file in the BufferReader by calling the gerReader method that's in bufferReader.
     * @param cars Reads the file cars.txt and stores it in an ArrayList by calling the readCarsFromBufferedReader method that's in the class bufferReader.
     * @param money Stores c.price into a double variable for formatting
     * @param format Converts the money variable back into a string
     *
     * CSC 1351 Programming Project No.1
     * section <002>
     * @author HannahLowery
     * @since 03/17/2024
     *  */
    public static void outPrint() {
        int count = 0;

        NumberFormat currency = NumberFormat.getCurrencyInstance();

        BufferedReader inputReader = bufferReader.getReader("output.txt"); //gets the user-inputted file
        ArrayList<Car> cars = bufferReader.readCarsFromBufferedReader(inputReader);

        Collections.sort(cars); //sorts the car.txt file

        //format the file output to the console
        System.out.println("-------------------------------------------");
        System.out.printf("%23s%n", "Car Project");
        System.out.println("-------------------------------------------");
        System.out.printf("| %-15s | %-9s | %-9s |%n", "Make", "Year", "Price");
        for (Car c : cars) { //for loop that reads the file until it is null
            if(!c.price.isEmpty()) { //makes sure the price isn't empty before formatting it
                double money = Double.parseDouble(c.price);
                String format = currency.format(money);
                System.out.println("-------------------------------------------");
                System.out.printf("| %-15s |%-9s | %-10s |%n", c.make, c.year, format);
                count++;
            }
            else{ //if the price is empty then it doesn't format it and just prints it regularly
                System.out.println("-------------------------------------------");
                System.out.printf("| %-15s |%-9s | %-10s |%n", c.make, c.year, c.price);
                count++;
            }
        }
        System.out.println("-------------------------------------------");
        System.out.println("You have: " + count+ " car" +(count != 1 ?"s. ": ". ")); //uses the conditional operator to evaluate the sentence
        bufferReader.closeReader(inputReader); //closes the BufferReader. closeReader is in the private inner-class
    }

    /*
     * bufferReader Is a public inner class that manipulates the BufferReader
     *
     * CSC 1351 Programming Project No.1
     * section <002>
     * @author Hannah Lowery
     * @Since 03/17/2024
     *  */
    public static class bufferReader {

        /*getReader method creates a BufferedReader object and takes the filename in a parameter
         *
         * @throws IOException
         * @param name Gets the name of the file
         * @param path Gets the string value of the file
         * @param in Takes in the file name and stores it in the BufferReader
         * @return The BufferedReader object returning the file
         *
         * CSC 1351 Programming Project No.1
         * section <002>
         * @author Hannah Lowery
         * @Since 03/17/2024
         * */
        static BufferedReader getReader(String name) {
            BufferedReader in = null;
            //in a try-catch block to make sure the exception is caught
            try {
                Path path = Path.of(name);
                in = Files.newBufferedReader(path);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "error opening file", "error", JOptionPane.WARNING_MESSAGE);
                System.exit(0); //exits the program if IOException is thrown
            }
            return in;
        }

        /*
         * closeReader method closes the BufferedReader
         * @param close Takes in the BufferedReader to close
         * @throws IOException
         *
         * CSC 1351 Programming Project No.1
         * section <002>
         * @author Hannah Lowery
         * @since 03/17/2024
         * */
        private static void closeReader(BufferedReader close) {
            //in a try-catch block to make sure the exception is caught
            try {
                close.close();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "error closing file", "error", JOptionPane.WARNING_MESSAGE);
                System.out.print(0); //exits program if it cannot close the file
            }
        }

        /*
         *readCarsFromBufferedReader creates an ArrayList Object that would allow the car to be comparedTo
         * @param cars An ArrayList that add the file to the new Car object if it isn't null
         * @param line A String that stores the BufferedReader file
         * @param data A String array that increments based on tabs in the file
         * @param make A String that stores whatever is proceeding a tab in this case the make of the car
         * @param year A String that stores whatever is proceeded after two tabs in this can the year of a car
         * @param price A String that stores whatever is proceeded after three tabs in this case the price of a car
         * @return the new cars Object
         *
         * CSC 1351 Programming Project No.1
         * Section<002>
         * @author Hannah Lowry
         * @since 03/17/2024
         * */

        private static ArrayList<Car> readCarsFromBufferedReader(BufferedReader in) {
            ArrayList<Car> cars = new ArrayList<>();
            String line;

            //in a try-catch block to make sure the exception is caught
            try {
                while ((line = in.readLine()) != null) { //makes sure in.readLine() isn't null
                    String[] data = line.split("[\\t,]",-1); // (uses regex) (the -1 prevents the tab from gooing past the index 4)
                    String make = data[1];
                    String year = data[2];
                    String price = data[3];
                    cars.add(new Car(make, year, price)); //stores the make,year,and price back into the Car object
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "error reading file", "error", JOptionPane.WARNING_MESSAGE);
                System.exit(0); //exits the program if there is an exception
            }
            return cars;
        }
    }
}






