import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import  javax.swing.*;
import java.io.*;


/*
 * CSC 1351
 *
 * CSC 1351 Programming Project No 1.
 * Section <002>

 * @Author Hannah Lowery
 * @Since 03/17/2024
 *
 * FileIn class allows the user to choose how they want to get their file to be output to the console
 * FileIn has one private inner-class:Cars
 *
 * */
public class FileIn {


    /*
     * userInput method: String object that puts all the methods together and converts them to Strings
     * @param result String object that stores the users file getting choice in a String
     * @param options String array object that gives the user options on how to get their file
     * @param option Var object that prompts the user and gives them a choice
     * @param output File object that stores the file
     * @return result
     *
     * CSC 1351 Programming Project No.1
     * section<002>
     *
     * @author Hannah Lowery
     * @since 03/17/2024
     * */
    public static String userInput() {
        String result = null;

        String[] options = {"quit", "output", "choose", "input", "default"};

        var option = JOptionPane.showOptionDialog(null, "How do you want to " +
                        "retrieve your file?",
                "select one:", 0, 3, null, options, options[0]);

        //if statements to check the users choice and depending on the choice is how the file is chosen
        if (option == 1) {
            Cars.allTogether(); //calls  the Cars class method allTogether if user chooses "output"
            File output = new File("oiasur.txt");
            return result = output.toString();

        } else if (option == 2) {
            //calles the JFileChooser method if user chooses "choose"
            return result = JFileChooser().toString();

        } else if (option == 3) {
            //calls the FileInput method if the user chooses "input"
            return result = FileInput().toString();
        } else if (option == 4) {
            //calls the Default method if user chooses "Default"
            return result = Default().toString();
        } else
            System.exit(0); //exits if the user chooses "quit"
        return result;
    }

    /*
     * JFileChooser method: File object that uses JFile Chooser to get the users choice
     * @param file A File object that stores the users File choose
     * @param isValid ensures the users choice is valid if not it prompts the user for input again
     * @param chooser JFileChooser that calls the JFile
     * @param result Int object that shows the open dialog box
     * @return file
     *
     * CSC 1351 Programming Project No.1
     * section<002>
     *
     * @author Hannah Lowery
     * @since 03/17/2024
     * */
    public static File JFileChooser() {
        File file = null;
        Boolean isValid = false;
        do {
            JFileChooser chooser = new JFileChooser();
            int result = chooser.showOpenDialog(null);
            //uses if -else statement to see if the user choose a file
            if (result == JFileChooser.APPROVE_OPTION) { //only stores the file if you choose "open"
                file = chooser.getSelectedFile();//stores the selected file
                if (file.exists()) { //checks whether the file exists so it can store it
                    isValid = true; //breaks out of the loop if the file exists
                    return file;
                } else {
                    JOptionPane.showMessageDialog(null, "file doesn't exist :(", "error", JOptionPane.WARNING_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "can't get file :(", "error", JOptionPane.WARNING_MESSAGE);
            }
        }
        while (!isValid); //keeps the loop going unless is-valid is true
        return file;
    }

    /*
     * FileInput method: File object that makes the user input the file name.
     * @param in Stores the File
     * @param isValid Boolean object makes the user re-enter file unless it exists or user presses cancel
     * @return in
     *
     * CSC 1351 Programming Project No.1
     * section<002>
     *
     * @author Hannah Lowery
     * @since 03/17/2024
     * */
    public static File FileInput()  {
        File in = null;
        boolean isValid = false;
        do { //do loop to prompt the user to enter a name
            String input = JOptionPane.showInputDialog(null, "Enter file name", "FileInput");
            if (input == null) {
                // User clicked Cancel
                System.exit(0);
            }
            in = new File(input);
            //checks whether the file exists
            if (in.exists()) {
                isValid = true;
            } else {
                JOptionPane.showMessageDialog(null, "File doesn't exist", "No File Found", JOptionPane.WARNING_MESSAGE);
            }
        } while (!isValid); //loops if isValid is false
        return in;
    }

    /*
     * Default method: File object that return the file name based on the PrintWriter object
     * @param in Stores the file name
     * @return in
     *
     * CSC 1351 Programming Project No.1
     * section<002>
     *
     * @author Hannah Lowery
     * @since 03/17/2024
     * */
    private static File Default() {


        File in = new File("input.txt");
        return in;
    }

    /*
     * Cars is a private inner-class that writes a file to the users directory if the user doesn't want to write it
     * @param add_delete Char object that sees whether the user wants to add/delete the line
     * @param make String object that gets the make of the car
     * @param year Int object to store the year
     * @param price Double object stores the price
     *
     * CSC 1351 Programming Project No.1
     * section<002>
     *
     * @author Hannah Lowery
     * @since 03/17/2024
     * */
    private static class Cars {
        private char add_delete;

        private String make;
        private int year;
        private double price;

        /*
         * Cars constructor initializes add_delete, make,year,price
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024
         * */
        public Cars(char add_delete, String make, int year, double price) {
            this.make = make;
            this.year = year;
            this.price = price;
            this.add_delete = add_delete;
        }

        /*
         * getCar method creates a Cars array object
         * @param cars sets the array length to 3 and the writes data to the arrays
         * @return cars
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024
         * */
        static Cars[] getCar() {
            Cars[] cars = new Cars[3];
            cars[0] = new Cars('A', "Kia", 2007, 4000);
            cars[1] = new Cars('A', "Honda", 2009, 10000);
            cars[2] = new Cars('A', "Toyota", 1999, 1800);

            return cars;
        }

        /*
         * openWriter method creates the PrintWriter object to send output file
         * @param out stores the output file
         * @param fileWriter appends data to the file stored
         * @throws IOException
         * @return out
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024
         * */

        static PrintWriter openWriter(String name) {
            PrintWriter out = null;
            //try-catch block catches the exception if thrown
            try {
                FileWriter fileWriter = new FileWriter(name, true);
                out = new PrintWriter(fileWriter);
                return out;
            } catch (IOException e) {
                System.out.println("I/O Error opening file.");
                System.exit(0); //exits the program
            }
            return out;
        }

        /*
         * writeMovie method formats the file and then outputs it
         * @param c A Cars object
         * @param out PrintWriter object that creates a PrintWriter object from line
         * @param line String object that formats the Cars data
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024
         * */
        static void writeMovie(Cars c, PrintWriter out) {
            String line = Character.toString(c.add_delete);
            line += "\t" + c.make;
            line += "\t" + Integer.toString(c.year);
            line += "\t" + Double.toString(c.price);
            out.println(line);
        }

        /*
         * allTogether prints everything to the console
         * @param cars A Cars array object that calls the getCar method
         * @param output PrintWriter object that calls the openWriter object
         *
         *
         * CSC 1351 Programming Project No.1
         * section<002>
         *
         * @author Hannah Lowery
         * @since 03/17/2024
         * */
        public static void allTogether() {
            Cars[] cars = getCar();
            //*
            PrintWriter output = openWriter("input.txt");
            //for loop to write the data to the write movie method for output
            for (Cars c : cars)
                writeMovie(c, output); //stores the data

            output.close(); //closes the PrintWriter
        }
    }
}

